// static/js/tasks-app.js

//CSRF
function getCSRFToken() {
    const tokenInput = document.getElementById('csrf-token');
    // گاهی اوقات توکن داخل اسکریپت است، گاهی اینپوت
    if (tokenInput && tokenInput.textContent) return tokenInput.textContent;
    if (tokenInput && tokenInput.value) return tokenInput.value;

    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                cookie = cookie.trim();
                if (cookie.startsWith(name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    return getCookie('csrftoken') || getCookie('csrf_token') || '';
}

//Modal Helpers
function getModalElements() {
    return {
        modal: document.getElementById('task-modal'),
        form: document.getElementById('task-form'),
        taskIdInput: document.getElementById('task-id'),
        titleInput: document.getElementById('task-title'),
        descInput: document.getElementById('task-description'),
        dueInput: document.getElementById('task-due-date'),
        priorityInput: document.getElementById('task-priority'),
        modalTitle: document.getElementById('modal-title'),
        submitBtn: document.getElementById('task-submit-btn') // باید ID دکمه را در HTML داشته باشیم
    };
}

function openModal() {
    const { modal } = getModalElements();
    if (modal) modal.style.display = 'block';
}

function closeTaskModal() {
    const { modal } = getModalElements();
    if (modal) modal.style.display = 'none';
}

function resetModalForm() {
    const els = getModalElements();
    if (els.form) els.form.reset();
    if (els.taskIdInput) els.taskIdInput.value = ''; 
    if (els.modalTitle) els.modalTitle.textContent = 'افزودن کار جدید';
    if (els.submitBtn) {
        els.submitBtn.disabled = false;
        els.submitBtn.textContent = 'ذخیره';
    }
}

// بستن مودال با کلیک بیرون آن
window.onclick = function(event) {
    const { modal } = getModalElements();
    if (modal && event.target === modal) {
        closeTaskModal();
    }
};

// Helpers 
function isoToLocalInput(datetimeIso) {
    if (!datetimeIso || datetimeIso === 'None') return '';
    // اگر فرمت درست است برگردان
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(datetimeIso)) return datetimeIso;

    const d = new Date(datetimeIso);
    if (isNaN(d)) return '';
    
    const pad = n => String(n).padStart(2, '0');
    const date = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
    const time = `${pad(d.getHours())}:${pad(d.getMinutes())}`;
    return `${date}T${time}`;
}

// Save (Create / Update)
async function saveTask(event) {
    // جلوگیری از رفرش پیش‌فرض مرورگر
    if (event) event.preventDefault();

    const els = getModalElements();
    const submitBtn = els.submitBtn || document.querySelector('#task-form button[type="submit"]');

    // جلوگیری از کلیک مجدد
    if(submitBtn) {
        if (submitBtn.disabled) return; 
        submitBtn.disabled = true; 
        submitBtn.textContent = 'در حال ذخیره...';
    }

    const taskId = els.taskIdInput ? els.taskIdInput.value : '';
    const title = els.titleInput.value.trim();
    const description = els.descInput.value.trim();
    const dueDateVal = els.dueInput.value;
    const priority = els.priorityInput.value;

    if (!title) {
        alert('عنوان را وارد کنید');
        if(submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'ذخیره';
        }
        return;
    }

    const data = {
        title: title,
        description: description || '',
        due_date: dueDateVal ? new Date(dueDateVal).toISOString() : null,
        priority: priority ? Number(priority) : 2
    };

    const csrf = getCSRFToken();
    const url = taskId ? `/api/tasks/${taskId}/update/` : `/api/tasks/create/`;
    
    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrf
            },
            body: JSON.stringify(data)
        });

        const txt = await res.text();
        let json;
        try {
            json = JSON.parse(txt);
        } catch(e) {
            console.error('JSON Parse Error:', txt);
            throw new Error('خطا در پردازش پاسخ سرور');
        }

        if (!res.ok) throw new Error(json.error || 'خطای سرور');

        if (json.success) {
            closeTaskModal();
            window.location.reload();
        } else {
            throw new Error(json.error || 'عملیات ناموفق بود');
        }
    } catch (err) {
        console.error('saveTask error', err);
        alert('خطا: ' + err.message);
        if(submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'ذخیره';
        }
    }
}

// Add New Task Handler
function handleAddNewTask() {
    resetModalForm(); 
    openModal();      
}

// Edit (Populate Modal)
function editTask(taskId) {
    const item = document.querySelector(`[data-task-id="${taskId}"]`);
    if (!item) {
        alert('تسک پیدا نشد');
        return;
    }

    const title = item.getAttribute('data-title');
    const description = item.getAttribute('data-description');
    const due = item.getAttribute('data-due');
    const priority = item.getAttribute('data-priority') || '2';


    resetModalForm();
    
   
    openModal();


    const els = getModalElements();
    if(els.taskIdInput) els.taskIdInput.value = taskId;
    if(els.titleInput) els.titleInput.value = title || '';
    if(els.descInput) els.descInput.value = description || '';
    if(els.priorityInput) els.priorityInput.value = priority;
    if(els.dueInput) els.dueInput.value = isoToLocalInput(due);
    
    if(els.modalTitle) els.modalTitle.textContent = 'ویرایش کار';
}

// Toggle Completed 
async function toggleTask(taskId, completed) {
    const csrf = getCSRFToken();
    try {
        const res = await fetch(`/api/tasks/${taskId}/update/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrf
            },
            body: JSON.stringify({ completed: Boolean(completed) })
        });
        
        const json = await res.json();
        if (json.success) {
            window.location.reload();
        } else {
            alert('خطا در تغییر وضعیت');
            // برگرداندن چک‌باکس
            const cb = document.querySelector(`[data-task-id="${taskId}"] .task-checkbox-input`);
            if(cb) cb.checked = !completed; 
        }
    } catch (err) {
        console.error(err);
        alert('خطا در ارتباط با سرور');
    }
}

// Delete 
async function deleteTask(taskId) {
    if (!confirm('آیا از حذف این کار مطمئن هستید؟')) return;
    
    const csrf = getCSRFToken();
    try {
        const res = await fetch(`/api/tasks/${taskId}/delete/`, {
            method: 'DELETE',
            headers: {
                'X-CSRFToken': csrf
            }
        });

        const json = await res.json();
        if (json.success) {
            const item = document.querySelector(`[data-task-id="${taskId}"]`);
            if (item) item.remove();
            else window.location.reload();
        } else {
            alert('خطا در حذف: ' + json.error);
        }
    } catch (err) {
        alert('خطا در حذف تسک');
    }
}

//Initialization
document.addEventListener('DOMContentLoaded', function() {
    // 1. تنظیم دکمه‌های افزودن (چون ممکن است چندتا باشد)
    const addBtns = document.querySelectorAll('.btn-add-task');
    addBtns.forEach(btn => {
        btn.onclick = handleAddNewTask; 
    });

    // 2. تنظیم فرم (فقط یک بار)
    const taskForm = document.getElementById('task-form');
    if (taskForm) {
        // حذف لیسنرهای قبلی و استفاده از onsubmit مستقیم
        taskForm.onsubmit = saveTask;
    }

    // 3. دکمه Esc
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeTaskModal();
    });
});