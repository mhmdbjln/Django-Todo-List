from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.core.validators import RegexValidator

# سیستم کاربر سفارشی 
class CustomUserManager(BaseUserManager):
    def create_user(self, email, phone_number, password=None, **extra_fields):
        if not email:
            raise ValueError('ایمیل باید وارد شود')
        email = self.normalize_email(email)
        user = self.model(email=email, phone_number=phone_number, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, phone_number, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        return self.create_user(email, phone_number, password, **extra_fields)


# مدل کاربر سفارشی
class User(AbstractUser):
    username = None  # حذف username 

    email = models.EmailField(
        unique=True,  #فیلد اصلی برای ورود
        verbose_name='ایمیل'
    )

    phone_number = models.CharField(
        max_length=11,
        unique=True,
        verbose_name='شماره موبایل',
        validators=[
            RegexValidator(
                regex=r'^09\d{9}$',
                message='شماره موبایل باید با 09 شروع شود و 11 رقم باشد'
            )
        ]
    )

    objects = CustomUserManager()

    USERNAME_FIELD = 'email' 
    REQUIRED_FIELDS = ['phone_number']

    def __str__(self):
        return self.email


# مدل Task
class Task(models.Model):
    # اتصال هر تسک به یک کاربر خاص
    user = models.ForeignKey(
        User, 
        on_delete=models.CASCADE,  #حذف تسک های کابر پاک شده
        related_name='tasks',
        verbose_name='کاربر',
        null=True, blank=True # برای جلوگیری از خطا در تسک‌های قدیمی
    )
    title = models.CharField(max_length=200, verbose_name='عنوان')
    description = models.TextField(blank=True, null=True, verbose_name='توضیحات')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاریخ ایجاد')
    due_date = models.DateTimeField(null=True, blank=True, verbose_name='تاریخ انجام')
    completed = models.BooleanField(default=False, verbose_name='انجام شده')

    priority = models.IntegerField(
        default=2,
        choices=[
            (1, 'کم'),
            (2, 'متوسط'),
            (3, 'زیاد')
        ],
        verbose_name='اولویت'
    )

    class Meta:
        verbose_name = 'کار'
        verbose_name_plural = 'کارها'
        ordering = ['-created_at'] #کارهای جدید بالای لیست قرار می گیرند

    def __str__(self):
        return self.title

    def is_overdue(self): #نشان دادن کارهای عقب‌افتاده
        if self.due_date and not self.completed:
            return timezone.now() > self.due_date
        return False