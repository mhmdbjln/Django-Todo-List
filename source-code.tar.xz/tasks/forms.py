# tasks/forms.py
from django import forms
from django.core.exceptions import ValidationError
from django.contrib.auth import get_user_model
import re

User = get_user_model()

def validate_iran_phone(value):
    pattern = r'^09\d{9}$'
    if not re.match(pattern, value):
        raise ValidationError('شماره تلفن معتبر ایرانی وارد کنید (مثال: 09123456789)')

class RegisterForm(forms.ModelForm): # تغییر ۱: ارث‌بری از ModelForm
    email = forms.EmailField(
        label='ایمیل',
        widget=forms.EmailInput(attrs={'class': 'form-input full-width', 'placeholder': 'example@email.com'})
    )
    # نام فیلد در فرم phone است اما در مدل phone_number است (در متد save هندل می‌شود)
    phone = forms.CharField(
        label='شماره تلفن',
        validators=[validate_iran_phone],
        widget=forms.TextInput(attrs={'class': 'form-input full-width', 'placeholder': '09123456789'})
    )
    password = forms.CharField(
        label='رمز عبور',
        widget=forms.PasswordInput(attrs={'class': 'form-input full-width', 'placeholder': 'رمز عبور'})
    )
    password_confirm = forms.CharField(
        label='تکرار رمز عبور',
        widget=forms.PasswordInput(attrs={'class': 'form-input full-width', 'placeholder': 'تکرار رمز عبور'})
    )

    # تغییر ۲: اضافه کردن کلاس Meta برای اتصال به مدل
    class Meta:
        model = User
        fields = ['email'] # فقط فیلدهایی که مستقیم مپ می‌شوند (phone و password دستی هندل می‌شوند)

    # بررسی تکراری نبودن ایمیل
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email__iexact=email).exists():
            raise ValidationError('این ایمیل قبلاً ثبت شده است')
        return email

    # بررسی تکراری نبودن شماره
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if User.objects.filter(phone_number=phone).exists():
            raise ValidationError('این شماره تلفن قبلاً ثبت شده است')
        return phone

    # بررسی یکسان بودن رمزعبور و تکرار رمزعبور
    def clean(self):
        cleaned_data = super().clean()
        p = cleaned_data.get('password')
        p2 = cleaned_data.get('password_confirm')
        if p and p2 and p != p2:
            raise ValidationError('رمز عبور و تکرار آن یکسان نیستند')
        return cleaned_data

    # تغییر ۳: اضافه کردن متد save برای رفع خطای AttributeError و ذخیره صحیح اطلاعات
    def save(self, commit=True):
        # ساخت نمونه کاربر بدون ذخیره در دیتابیس
        user = super().save(commit=False)
        
        # پر کردن دستی فیلدهایی که نامشان در فرم و مدل متفاوت است یا نیاز به پردازش دارند
        user.email = self.cleaned_data['email']
        user.phone_number = self.cleaned_data['phone'] # اتصال phone فرم به phone_number مدل
        user.set_password(self.cleaned_data['password']) # هش کردن رمز عبور
        
        if commit:
            user.save()
            
        return user