from django.urls import path
from . import views

urlpatterns = [
    # آدرس اصلی سایت مستقیماً صفحه ثبت‌نام را باز می‌کند
    path('', views.register_view, name='home'),

    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    path('mydays/', views.mydays, name='mydays'),
    path('next7days/', views.next7days, name='next7days'),
    path('all-tasks/', views.all_tasks, name='all_tasks'),

    # API Endpoints
    path('api/tasks/create/', views.create_task, name='create_task_api'),
    path('api/tasks/<int:task_id>/update/', views.update_task, name='update_task_api'),
    path('api/tasks/<int:task_id>/delete/', views.delete_task, name='delete_task_api'),
]