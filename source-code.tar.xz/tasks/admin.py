"سفارشی سازی نحوه نمایش و مدیریت تسک ها در پنل ادمین"
from django.contrib import admin
from .models import Task


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    "تنظیمات نمایش تسک"
    list_display = ['title', 'completed', 'priority', 'due_date', 'created_at']
    list_filter = ['completed', 'priority', 'created_at']
    search_fields = ['title', 'description']
    list_editable = ['completed', 'priority']
