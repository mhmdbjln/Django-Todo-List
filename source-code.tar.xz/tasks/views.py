from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from datetime import timedelta
import json
from .forms import RegisterForm
from .models import Task

# بخش احراز هویت
def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST) #اعتبارسنجی
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('mydays') #درصورت موفیت،ورود به صفحه روزهای من
    else:
        form = RegisterForm()
    return render(request, 'tasks/register.html', {'form': form})

def login_view(request):
    error = None
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = authenticate(request, username=email, password=password) #بررسی مطابقت ایمیل و پسورد
        
        if user is not None:
            login(request, user)
            return redirect('mydays')
        else:
            error = "ایمیل یا رمز عبور اشتباه است."

    return render(request, 'tasks/login.html', {'error': error})

def logout_view(request):
    logout(request)
    return redirect('login')


# نمایش صفحات
@login_required #بدون لاگین نمیتوان صفحات را مشاهده کرد
def mydays(request):
    today = timezone.now().date()
    
    tasks = Task.objects.filter(
        user=request.user,
        completed=False,
        due_date__date__lte=today
    ).order_by('due_date', '-priority')
    
    completed_tasks = Task.objects.filter(
        user=request.user,
        completed=True,
        due_date__date__lte=today
    ).order_by('-created_at')

    return render(request, 'tasks/mydays.html', {
        'tasks': tasks,
        'completed_tasks': completed_tasks,
        'page_title': 'روزهای من'
    })

@login_required
def next7days(request):
    today = timezone.now().date()
    next_week = today + timedelta(days=7)
    
    tasks = Task.objects.filter(
        user=request.user,
        due_date__date__gt=today,
        due_date__date__lte=next_week,
        completed=False
    ).order_by('due_date', '-priority')

    completed_tasks = Task.objects.filter(
        user=request.user,
        due_date__date__gt=today,
        due_date__date__lte=next_week,
        completed=True
    ).order_by('-created_at')

    return render(request, 'tasks/next7days.html', {
        'tasks': tasks,
        'completed_tasks': completed_tasks,
        'page_title': '7 روز آینده'
    })

@login_required
def all_tasks(request):
    status = request.GET.get('status', 'all') #all پیش فرض
    
    tasks_query = Task.objects.filter(user=request.user).order_by('-created_at')

    if status == 'completed':
        tasks_query = tasks_query.filter(completed=True)
    elif status == 'pending':
        tasks_query = tasks_query.filter(completed=False)
    

    return render(request, 'tasks/all_tasks.html', {
        'tasks': tasks_query,
        'page_title': 'همه کارها',
        'current_status': status # برای روشن نگه داشتن دکمه فعال در html
    })

#عملیات سریع
@login_required
@require_http_methods(["POST"])
def create_task(request):
    try:
        data = json.loads(request.body)
        title = data.get('title')
        if not title:
            return JsonResponse({'success': False, 'error': 'Title required'}, status=400)
        
        task = Task.objects.create(
            user=request.user,
            title=title,
            description=data.get('description', ''),
            due_date=data.get('due_date'),
            priority=data.get('priority', 2)
        )
        return JsonResponse({'success': True, 'id': task.id})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
@require_http_methods(["POST"])
def update_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user) 
    try:
        data = json.loads(request.body)
        if 'title' in data: task.title = data['title']
        if 'description' in data: task.description = data['description']
        if 'due_date' in data: task.due_date = data['due_date']
        if 'priority' in data: task.priority = data['priority']
        if 'completed' in data: task.completed = data['completed']
        task.save()
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
@require_http_methods(["DELETE"])
def delete_task(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.delete()
    return JsonResponse({'success': True})